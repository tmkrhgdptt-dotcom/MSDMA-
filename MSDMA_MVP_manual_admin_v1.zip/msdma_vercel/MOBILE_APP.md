# MSDMA — version mobile

Cette version est une PWA installable sur Android et iPhone depuis le navigateur, sans passer par un store.

## Installation
1. Lancer le serveur MSDMA en HTTPS.
2. Ouvrir MSDMA dans Chrome Android ou Safari iPhone.
3. Android : menu du navigateur → « Installer l'application » / « Ajouter à l'écran d'accueil ».
4. iPhone : Partager → « Sur l'écran d'accueil ».

## APK Android
Le projet est déjà structuré comme une PWA. Pour publier un APK/AAB, utiliser un wrapper Android (Capacitor/TWA) sur une machine disposant du SDK Android et de la clé de signature. Les secrets de production ne doivent jamais être placés dans le dépôt.
