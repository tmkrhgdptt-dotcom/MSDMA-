# MSDMA — déploiement Vercel

## 1. Importer le projet
Depuis Vercel, choisissez **Import Project** puis envoyez ce dossier/projet.

## 2. Base de données
Dans le projet Vercel, ajoutez une base PostgreSQL via le Marketplace. L'intégration Neon est recommandée pour ce projet. Elle fournit une variable `DATABASE_URL` utilisable par l'application.

## 3. Variables d'environnement
Ajoutez au minimum :
- `DATABASE_URL`
- `JWT_SECRET`
- `ADMIN_PHONE`
- `ADMIN_PASSWORD`
- `ADMIN_NAME`
- `COMMISSION_RATE=0.10`
- `PAYMENT_MODE=demo`

Ne mettez jamais ces secrets dans le code ou dans l'application mobile.

## 4. Après le premier déploiement
Ouvrez :
`https://VOTRE-DOMAINE.vercel.app/api/health`

Vous devez obtenir un JSON indiquant que le service MSDMA fonctionne.

## 5. Paiement
Le paiement reste en mode démo. Les identifiants Orange Money/MTN ne doivent être ajoutés qu'après validation des comptes marchands et de l'intégration correspondante.

## 6. Migration VPS plus tard
Le backend reste Express + PostgreSQL. Le code peut être déplacé vers un VPS plus tard ; la base et les variables d'environnement sont séparées de l'hébergement.
