# MSDMA — Paiement sécurisé v3

Cette version ajoute un **escrow en mode démo** :
1. Le client autorise le montant de la mission.
2. La mission devient acceptée uniquement si le paiement est autorisé.
3. Le prestataire termine la mission.
4. Le montant est alors marqué comme libéré au prestataire.

⚠️ **Mode démo uniquement : aucun argent réel n'est déplacé.**

Pour la production, il faudra connecter un prestataire de paiement réellement disponible en Guinée, avec ses clés/API, webhooks, gestion des erreurs, KYC/AML si applicable et compte marchand au nom de l'entreprise.
