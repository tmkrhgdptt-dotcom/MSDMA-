# MSDMA — déploiement Netlify

Cette version est préparée pour commencer sur Netlify tout en restant migrable vers un VPS.

## 1. Base PostgreSQL

Créer une base PostgreSQL gérée et récupérer son `DATABASE_URL`.

Variables Netlify à configurer :
- `DATABASE_URL`
- `JWT_SECRET`
- `ADMIN_PHONE`
- `ADMIN_PASSWORD`
- `ADMIN_NAME`
- `COMMISSION_RATE` (ex. `0.10`)
- `PAYMENT_MODE=demo`
- `CORS_ORIGIN` = domaine Netlify de l'application

Ne jamais mettre ces secrets dans Git ou dans le code de l'application mobile.

## 2. Déploiement

Importer ce dossier comme projet Netlify. Le fichier `netlify.toml` configure automatiquement le dossier public et les Functions.

Après déploiement, tester :
- `/api/health`
- inscription
- connexion
- création d'une mission
- financement démo
- acceptation
- fin de mission

## 3. Migration VPS plus tard

L'API reste Express + PostgreSQL. Pour migrer :
- conserver le même `DATABASE_URL` ou migrer les données vers PostgreSQL du VPS ;
- remettre `NETLIFY` à une valeur différente de `true` ;
- lancer `node server.js` dans Docker/VPS ;
- conserver les mêmes variables d'environnement.

Aucun paiement réel n'est activé dans cette version.
