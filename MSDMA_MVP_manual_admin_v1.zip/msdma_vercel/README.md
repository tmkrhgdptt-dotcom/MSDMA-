# MSDMA Fullstack v1

MSDMA est maintenant relié à une vraie API Express + PostgreSQL et à une interface web mobile responsive.

## Lancer en local

1. Installer Node.js 20+ et Docker.
2. `cp .env.example .env`
3. `docker compose up -d`
4. `npm install`
5. `npm start`
6. Ouvrir `http://localhost:4000`

La base PostgreSQL est initialisée automatiquement avec `sql/schema.sql`.

## Ce qui est déjà connecté
- création de compte et connexion JWT
- rôles client/prestataire/both
- publication de tâches
- liste des tâches depuis PostgreSQL
- acceptation transactionnelle d'une tâche
- protection contre l'auto-acceptation
- structure de messagerie API
- interface mobile MSDMA servie par le même serveur

## Administration et modèle économique
- panneau administrateur intégré à l'interface
- statistiques utilisateurs / missions / paiements
- vérification et suspension des comptes
- suivi des paiements et des commissions
- commission configurable via `COMMISSION_RATE` (10% par défaut)
- bootstrap d'un administrateur via `ADMIN_PHONE` + `ADMIN_PASSWORD`
- à la libération d'une mission, la commission et le montant net prestataire sont enregistrés en base

Le paiement reste en mode démo : aucun argent réel n'est déplacé tant qu'un prestataire de paiement réel n'est pas connecté.

Ne pas utiliser les secrets de l'exemple en production. Déployer avec HTTPS et des secrets privés.

## Application Android
Le dossier `mobile/` contient une configuration Capacitor prête à être transformée en projet Android (`com.msdma.app`). La compilation APK/AAB nécessite Android Studio + Android SDK sur une machine de build.
