# MSDMA — passage au paiement réel

## État actuel
Le projet reste en `PAYMENT_MODE=demo` par défaut. Aucun argent réel n'est déplacé.

## Pourquoi
Pour activer les paiements réels, MSDMA doit obtenir un compte marchand et les identifiants/API du ou des opérateurs agréés. Orange indique officiellement que son Web Payment / M Payment est disponible en Guinée Conakry et réservé aux marchands qui remplissent les conditions d'inscription et de conformité.

## Architecture
- `POST /api/tasks/:id/fund` accepte `demo`, `orange_money` ou `mtn_momo`.
- En mode démo, la transaction est simulée.
- En mode live, les connecteurs opérateurs ne sont pas activés tant que les credentials et paramètres contractuels ne sont pas présents.
- `POST /api/payments/webhook/:provider` est le point d'entrée prévu pour les callbacks.

## Avant production
1. Créer l'entité/compte marchand MSDMA et terminer la conformité requise.
2. Obtenir les credentials sandbox puis production de l'opérateur choisi.
3. Implémenter le checkout/redirect ou le flux API exact fourni par l'opérateur.
4. Vérifier la signature des webhooks et l'idempotence des callbacks.
5. Ajouter une vraie réconciliation et un journal d'audit des paiements.
6. Tester remboursements, échecs, doublons, expirations et litiges.
7. Faire valider le modèle de séquestre/libération par le partenaire de paiement et le cadre réglementaire applicable avant de conserver des fonds pour des tiers.

## Opérateurs
Orange Money documente officiellement le Web Payment / M Payment et mentionne la Guinée Conakry parmi les pays disponibles. Voir la documentation officielle : https://developer.orange.com/apis/om-webpay

Les offres et conditions commerciales peuvent changer : confirmer les tarifs, limites et exigences directement avec l'opérateur avant activation.
