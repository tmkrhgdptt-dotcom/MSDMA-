import jwt from 'jsonwebtoken';
import 'dotenv/config';
export function signUser(user){ return jwt.sign({sub:user.id, role:user.role, name:user.name, is_admin:Boolean(user.is_admin)}, process.env.JWT_SECRET, {expiresIn:'7d'}); }
export function requireAuth(req,res,next){
  const token=req.headers.authorization?.startsWith('Bearer ')?req.headers.authorization.slice(7):null;
  if(!token) return res.status(401).json({error:'Authentification requise'});
  try{ req.user=jwt.verify(token, process.env.JWT_SECRET); next(); }
  catch{ return res.status(401).json({error:'Session invalide ou expirée'}); }
}

export function requireAdmin(req,res,next){ if(!req.user?.is_admin) return res.status(403).json({error:'Accès administrateur requis'}); next(); }
