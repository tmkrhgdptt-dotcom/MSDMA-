# MSDMA v6 — préparation production

Cette version ajoute des garde-fous techniques avant l’activation de paiements réels :

- limitation des tentatives sur authentification et paiements ;
- `Idempotency-Key` obligatoire pour financer une mission ;
- journal d’audit des actions sensibles ;
- stockage des événements webhook avec anti-duplication ;
- vérification HMAC des webhooks ;
- traitement générique des statuts de paiement ;
- champs de note pour la vérification des utilisateurs.

## Paiements réels

Le code reste en mode `PAYMENT_MODE=demo` par défaut. Ne passez pas en `live` sans avoir obtenu les accès marchands et la documentation exacte du fournisseur.

Orange indique que son Orange Money Web Payment est disponible en Guinée Conakry pour les marchands Orange Money et que l’accès passe par une souscription/validation locale. MTN indique également que son produit Payments V1 couvre la Guinée.

Les endpoints `/api/payments/webhook/:provider` sont conçus pour recevoir les callbacks du fournisseur, mais le mapping final des champs doit être aligné sur le contrat/API réellement fourni à MSDMA.

## Avant production

1. Obtenir le statut marchand/KYA et les identifiants officiels.
2. Récupérer la documentation sandbox et production du fournisseur retenu.
3. Configurer HTTPS et des secrets hors du dépôt.
4. Tester paiements réussis, refusés, expirés, doublons, remboursements et webhooks répétés.
5. Faire valider les flux de conservation/libération des fonds et la conformité applicable avant d’encaisser de l’argent réel.
