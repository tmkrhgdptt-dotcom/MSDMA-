# MSDMA — déploiement serveur

## Ce que cette version apporte
- API Node.js conteneurisée
- PostgreSQL persistant
- HTTPS via Caddy
- redémarrage automatique des services
- endpoint de santé : `/api/health`
- secrets séparés dans `.env`
- paiement toujours en mode `demo`

## 1. Préparer un serveur
Utiliser un VPS Linux avec Docker + Docker Compose et un nom de domaine, par exemple `api.msdma.example`.

## 2. Installer les fichiers
Décompresser le projet sur le serveur, puis entrer dans `MSDMA_fullstack_v1`.

Copier `.env.production.example` vers `.env` et remplacer **toutes** les valeurs `CHANGE_...`.

Générer de longs secrets aléatoires pour `JWT_SECRET` et `POSTGRES_PASSWORD`.

## 3. Domaine
Modifier `Caddyfile` :

`api.msdma.example { reverse_proxy api:4000 }`

Le DNS A/AAAA du domaine doit pointer vers l'IP du serveur.

## 4. Démarrer

`docker compose -f docker-compose.production.yml up -d --build`

Vérifier :

`docker compose -f docker-compose.production.yml ps`

Puis ouvrir :

`https://api.msdma.example/api/health`

La réponse attendue est un JSON avec `ok: true`.

## 5. Première connexion administrateur
Le compte administrateur est créé au démarrage à partir de `ADMIN_PHONE` et `ADMIN_PASSWORD`.
Changez le mot de passe initial après le premier accès si votre version de l'interface le permet.

## 6. Sauvegarde PostgreSQL
Exemple de sauvegarde :

`docker compose -f docker-compose.production.yml exec -T db pg_dump -U msdma msdma > backup.sql`

Conserver les sauvegardes hors du serveur.

## 7. Avant paiement réel
Ne passez pas `PAYMENT_MODE` à `live` sans avoir obtenu les comptes marchands, identifiants, URLs et règles de webhook officiels du prestataire choisi. Tester d'abord en environnement de test.

## 8. Après mise en ligne
Mettre à jour `CORS_ORIGIN` avec le domaine réel de l'application web. Pour l'app Android, utiliser l'URL HTTPS réelle de l'API dans la configuration mobile.
