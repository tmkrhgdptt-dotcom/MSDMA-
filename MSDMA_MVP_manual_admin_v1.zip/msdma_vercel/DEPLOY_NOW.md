# MSDMA — mise en ligne

Cette archive est prête pour un VPS Linux avec Docker et un domaine.

## Ce qu'il faut encore fournir
1. IP d'un VPS Linux
2. Un domaine ou sous-domaine, par exemple `api.tondomaine.com`
3. Accès SSH au VPS

## Déploiement
Sur le serveur:

```bash
unzip MSDMA_Server_Production_v2.zip
cd msdma_deploy
cp .env.production.example .env
nano .env
DOMAIN=api.tondomaine.com ./deploy.sh
```

Le DNS `A`/`AAAA` du domaine doit pointer vers l'IP du VPS. Caddy demandera automatiquement le certificat TLS lorsque le domaine sera correctement pointé et que les ports 80/443 sont accessibles.

## Vérification
```bash
curl https://api.tondomaine.com/api/health
```

## Sauvegarde
```bash
./backup.sh
```

## Important
Le paiement reste en mode `demo`. Ne mets pas les clés de paiement dans l'application mobile. Elles doivent rester uniquement sur le serveur.
