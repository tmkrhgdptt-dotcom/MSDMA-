# MSDMA — checklist avant mise en ligne

- [ ] Hébergement HTTPS avec domaine MSDMA
- [ ] PostgreSQL managé avec sauvegardes
- [ ] JWT_SECRET et mots de passe admin longs, uniques et secrets
- [ ] CORS limité au domaine officiel
- [ ] Compte marchand et conformité paiement finalisés
- [ ] Webhooks signés + idempotence
- [ ] Logs et alertes sans exposer les secrets
- [ ] Sauvegarde/restauration testée
- [ ] Politique de confidentialité et conditions d'utilisation
- [ ] Processus de vérification des prestataires
- [ ] Procédure de litige/remboursement
- [ ] Tests de charge et sécurité
- [ ] Tests réels avec petits montants avant ouverture complète
