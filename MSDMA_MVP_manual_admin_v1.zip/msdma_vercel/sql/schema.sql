import express from 'express';
import cors from 'cors';
import bcrypt from 'bcryptjs';
import { z } from 'zod';
import 'dotenv/config';
import path from 'path';
import { fileURLToPath } from 'url';
import crypto from 'crypto';
import rateLimit from 'express-rate-limit';
import { pool } from './db.js';
import { requireAuth, requireAdmin, signUser } from './auth.js';

const __dirname = path.dirname(fileURLToPath(import.meta.url));
const app = express();
app.use(cors({origin: process.env.CORS_ORIGIN ? process.env.CORS_ORIGIN.split(',').map(s=>s.trim()) : true}));
app.use(express.json({limit:'1mb'}));
app.use('/api/auth/', rateLimit({windowMs: 15*60*1000, max: 30, standardHeaders: true, legacyHeaders: false, message: {error:'Trop de tentatives. Réessaie plus tard.'}}));
app.use('/api/payments/', rateLimit({windowMs: 60*1000, max: 60, standardHeaders: true, legacyHeaders: false}));
app.disable('x-powered-by');
app.use((req,res,next)=>{res.setHeader('X-Content-Type-Options','nosniff');res.setHeader('X-Frame-Options','DENY');res.setHeader('Referrer-Policy','strict-origin-when-cross-origin');next();});

const COMMISSION_RATE = Math.min(0.30, Math.max(0, Number(process.env.COMMISSION_RATE ?? 0.10)));

async function ensureAdmin(){
  if(!process.env.ADMIN_EMAIL || !process.env.ADMIN_PASSWORD) return;
  const existing=await pool.query('SELECT id FROM users WHERE email=$1',[process.env.ADMIN_EMAIL.toLowerCase()]);
  if(existing.rowCount) { await pool.query("UPDATE users SET is_admin=true, account_status='active', verification_status='verified', verified_at=COALESCE(verified_at,now()) WHERE email=$1",[process.env.ADMIN_EMAIL.toLowerCase()]); return; }
  const hash=await bcrypt.hash(process.env.ADMIN_PASSWORD,12);
  await pool.query(`INSERT INTO users(name,email,phone,password_hash,role,is_admin,verification_status,verified_at) VALUES($1,$2,$3,$4,'both',true,'verified',now())`,[process.env.ADMIN_NAME||'MSDMA Admin',process.env.ADMIN_EMAIL.toLowerCase(),process.env.ADMIN_PHONE||'000000000',hash]);
}

await pool.query('ALTER TABLE users ADD COLUMN IF NOT EXISTS last_lat DOUBLE PRECISION').catch(()=>{});
await pool.query('ALTER TABLE users ADD COLUMN IF NOT EXISTS last_lng DOUBLE PRECISION').catch(()=>{});
await pool.query('ALTER TABLE users ADD COLUMN IF NOT EXISTS last_location_at TIMESTAMPTZ').catch(()=>{});
await pool.query("ALTER TABLE users ADD COLUMN IF NOT EXISTS is_admin BOOLEAN NOT NULL DEFAULT false").catch(()=>{});
await pool.query("ALTER TABLE users ADD COLUMN IF NOT EXISTS account_status TEXT NOT NULL DEFAULT 'active'").catch(()=>{});
await pool.query("ALTER TABLE users ADD COLUMN IF NOT EXISTS verification_status TEXT NOT NULL DEFAULT 'unverified'").catch(()=>{});
await pool.query("ALTER TABLE users ADD COLUMN IF NOT EXISTS verified_at TIMESTAMPTZ").catch(()=>{});
await pool.query("ALTER TABLE payments ADD COLUMN IF NOT EXISTS commission_gnf INTEGER NOT NULL DEFAULT 0").catch(()=>{});
await pool.query("ALTER TABLE payments ADD COLUMN IF NOT EXISTS payout_gnf INTEGER NOT NULL DEFAULT 0").catch(()=>{});
await pool.query("ALTER TABLE payments ADD COLUMN IF NOT EXISTS idempotency_key TEXT").catch(()=>{});
await pool.query("ALTER TABLE payments ADD COLUMN IF NOT EXISTS failure_reason TEXT").catch(()=>{});
await pool.query("ALTER TABLE users ADD COLUMN IF NOT EXISTS verification_note TEXT").catch(()=>{});
await pool.query("ALTER TABLE users ADD COLUMN IF NOT EXISTS email TEXT").catch(()=>{});
await pool.query("CREATE UNIQUE INDEX IF NOT EXISTS idx_users_email ON users(lower(email)) WHERE email IS NOT NULL").catch(()=>{});
await pool.query("ALTER TABLE users ADD COLUMN IF NOT EXISTS vehicle_type TEXT").catch(()=>{});
await pool.query("ALTER TABLE users ADD COLUMN IF NOT EXISTS driver_status TEXT NOT NULL DEFAULT 'pending'").catch(()=>{});
await pool.query("ALTER TABLE tasks ADD COLUMN IF NOT EXISTS payment_status TEXT NOT NULL DEFAULT 'unpaid'").catch(()=>{});
await pool.query("ALTER TABLE payments DROP CONSTRAINT IF EXISTS payments_status_check").catch(()=>{});
await pool.query("ALTER TABLE payments ADD CONSTRAINT payments_status_check CHECK (status IN ('pending','authorized','released','refunded','failed'))").catch(()=>{});
await pool.query(`CREATE TABLE IF NOT EXISTS notifications (id UUID PRIMARY KEY DEFAULT gen_random_uuid(), user_id UUID NOT NULL REFERENCES users(id) ON DELETE CASCADE, title TEXT NOT NULL, body TEXT NOT NULL, read_at TIMESTAMPTZ, created_at TIMESTAMPTZ NOT NULL DEFAULT now())`).catch(()=>{});
await pool.query(`CREATE TABLE IF NOT EXISTS webhook_events (id UUID PRIMARY KEY DEFAULT gen_random_uuid(), provider TEXT NOT NULL, event_id TEXT NOT NULL, payload JSONB NOT NULL, received_at TIMESTAMPTZ NOT NULL DEFAULT now(), UNIQUE(provider,event_id))`).catch(()=>{});
await pool.query(`CREATE TABLE IF NOT EXISTS audit_logs (id UUID PRIMARY KEY DEFAULT gen_random_uuid(), actor_id UUID REFERENCES users(id) ON DELETE SET NULL, action TEXT NOT NULL, entity_type TEXT NOT NULL, entity_id UUID, metadata JSONB, created_at TIMESTAMPTZ NOT NULL DEFAULT now())`).catch(()=>{});
await pool.query("CREATE INDEX IF NOT EXISTS idx_audit_created ON audit_logs(created_at DESC)").catch(()=>{});
await ensureAdmin().catch(err=>console.error('Admin bootstrap:',err.message));

app.get('/api/health', async (_req,res)=>{
  try { await pool.query('SELECT 1'); res.json({ok:true,service:'MSDMA API'}); }
  catch { res.status(503).json({ok:false,error:'Base de données indisponible'}); }
});

const registerSchema=z.object({name:z.string().trim().min(2).max(80),email:z.string().email().max(160),phone:z.string().trim().min(6).max(30),password:z.string().min(6).max(100),role:z.enum(['client','prestataire','both']).default('both')});
app.post('/api/auth/register',async(req,res,next)=>{
  const p=registerSchema.safeParse(req.body); if(!p.success)return res.status(400).json({error:'Données invalides',details:p.error.flatten()});
  const {name,email,phone,password,role}=p.data;
  try { const hash=await bcrypt.hash(password,12); const r=await pool.query('INSERT INTO users(name,email,phone,password_hash,role) VALUES($1,$2,$3,$4,$5) RETURNING id,name,email,phone,role,is_admin,account_status,verification_status,created_at',[name,email.toLowerCase(),phone,hash,role]); const user=r.rows[0]; res.status(201).json({user,token:signUser(user)}); }
  catch(e){ if(e.code==='23505')return res.status(409).json({error:'Cet e-mail ou ce numéro est déjà utilisé'}); next(e); }
});

app.post('/api/auth/login',async(req,res,next)=>{
  const p=z.object({identifier:z.string().trim().min(3),password:z.string()}).safeParse(req.body); if(!p.success)return res.status(400).json({error:'Données invalides'});
  try { const r=await pool.query('SELECT id,name,email,phone,password_hash,role,is_admin,account_status,verification_status,created_at FROM users WHERE lower(email)=lower($1) OR phone=$1 LIMIT 1',[p.data.identifier]); if(!r.rowCount || !(await bcrypt.compare(p.data.password,r.rows[0].password_hash)))return res.status(401).json({error:'E-mail/téléphone ou mot de passe incorrect'}); if(r.rows[0].account_status==='suspended')return res.status(403).json({error:'Compte suspendu. Contacte MSDMA.'}); const {password_hash,...user}=r.rows[0]; res.json({user,token:signUser(user)}); } catch(e){next(e);}
});

app.get('/api/me',requireAuth,async(req,res,next)=>{try{const r=await pool.query('SELECT id,name,email,phone,role,is_admin,account_status,verification_status,verified_at,created_at,vehicle_type,driver_status FROM users WHERE id=$1',[req.user.sub]); if(!r.rowCount)return res.status(404).json({error:'Utilisateur introuvable'}); res.json(r.rows[0]);}catch(e){next(e);}});

app.post('/api/me/location',requireAuth,async(req,res,next)=>{const p=z.object({lat:z.number().finite().min(-90).max(90),lng:z.number().finite().min(-180).max(180)}).safeParse(req.body);if(!p.success)return res.status(400).json({error:'Position invalide'});try{await pool.query('UPDATE users SET last_lat=$1,last_lng=$2,last_location_at=now() WHERE id=$3',[p.data.lat,p.data.lng,req.user.sub]);res.json({ok:true});}catch(e){next(e);}});

const coord=z.number().finite().min(-180).max(180);
const taskSchema=z.object({title:z.string().trim().min(3).max(120),description:z.string().trim().min(3).max(2000),category:z.string().trim().min(2).max(50),pickup:z.string().trim().min(2).max(200),destination:z.string().trim().min(2).max(200),price_gnf:z.number().int().positive().max(100000000),pickup_lat:z.number().finite().min(-90).max(90).nullable().optional(),pickup_lng:coord.nullable().optional(),destination_lat:z.number().finite().min(-90).max(90).nullable().optional(),destination_lng:coord.nullable().optional()});
app.post('/api/tasks',requireAuth,async(req,res,next)=>{const p=taskSchema.safeParse(req.body);if(!p.success)return res.status(400).json({error:'Données invalides',details:p.error.flatten()});try{const x=p.data;const r=await pool.query('INSERT INTO tasks(client_id,title,description,category,pickup,destination,price_gnf,pickup_lat,pickup_lng,destination_lat,destination_lng) VALUES($1,$2,$3,$4,$5,$6,$7,$8,$9,$10,$11) RETURNING *',[req.user.sub,x.title,x.description,x.category,x.pickup,x.destination,x.price_gnf,x.pickup_lat??null,x.pickup_lng??null,x.destination_lat??null,x.destination_lng??null]);res.status(201).json(r.rows[0]);}catch(e){next(e);}});

app.get('/api/tasks',requireAuth,async(req,res,next)=>{try{const status=['available','accepted','completed','cancelled'].includes(req.query.status)?req.query.status:'available';const r=await pool.query(`SELECT t.*, u.name AS client_name, p.name AS provider_name FROM tasks t JOIN users u ON u.id=t.client_id LEFT JOIN users p ON p.id=t.provider_id WHERE t.status=$1 ORDER BY t.created_at DESC LIMIT 100`,[status]);res.json(r.rows);}catch(e){next(e);}});
app.get('/api/tasks/:id',requireAuth,async(req,res,next)=>{try{const r=await pool.query('SELECT t.*,u.name AS client_name,p.name AS provider_name FROM tasks t JOIN users u ON u.id=t.client_id LEFT JOIN users p ON p.id=t.provider_id WHERE t.id=$1',[req.params.id]);if(!r.rowCount)return res.status(404).json({error:'Tâche introuvable'});res.json(r.rows[0]);}catch(e){next(e);}});

// Payment layer: sandbox by default. Real Orange Money / MTN credentials are required for live money.
const PAYMENT_MODE=(process.env.PAYMENT_MODE||'demo').toLowerCase();
const ORANGE_WEBPAY_URL=process.env.ORANGE_WEBPAY_URL||'';
const PAYMENT_RETURN_URL=process.env.PAYMENT_RETURN_URL||'';

async function audit(actorId, action, entityType, entityId=null, metadata={}){
  try{ await pool.query('INSERT INTO audit_logs(actor_id,action,entity_type,entity_id,metadata) VALUES($1,$2,$3,$4,$5)',[actorId||null,action,entityType,entityId,JSON.stringify(metadata)]); }catch(e){ console.error('audit log:',e.message); }
}

function safeEqualHex(a,b){ try{ const aa=Buffer.from(a,'hex'), bb=Buffer.from(b,'hex'); return aa.length===bb.length && aa.length>0 && crypto.timingSafeEqual(aa,bb); }catch{return false;} }

function paymentProviderStatus(){
  return {mode:PAYMENT_MODE, orangeConfigured:Boolean(process.env.ORANGE_CLIENT_ID&&process.env.ORANGE_CLIENT_SECRET&&ORANGE_WEBPAY_URL), returnUrlConfigured:Boolean(PAYMENT_RETURN_URL)};
}

app.get('/api/payments/config',requireAuth,async(_req,res)=>res.json({currency:'GNF',...paymentProviderStatus(), providers:['demo','orange_money','mtn_momo']}));

app.post('/api/tasks/:id/fund',requireAuth,async(req,res,next)=>{
  const idempotencyKey=String(req.body?.idempotency_key||crypto.randomUUID());
  const c=await pool.connect();
  try{
    await c.query('BEGIN');
    const t=await c.query('SELECT id,client_id,price_gnf,status,title FROM tasks WHERE id=$1 FOR UPDATE',[req.params.id]);
    if(!t.rowCount){await c.query('ROLLBACK');return res.status(404).json({error:'Tâche introuvable'});}
    const task=t.rows[0];
    if(task.client_id!==req.user.sub)return res.status(403).json({error:'Seul le client peut payer la tâche'});
    if(task.status!=='available')return res.status(409).json({error:'Cette tâche n’est plus disponible'});
    const existing=await c.query('SELECT * FROM payments WHERE task_id=$1 OR idempotency_key=$2',[task.id,idempotencyKey]);
    if(existing.rowCount){await c.query('ROLLBACK');return res.status(409).json({error:'Cette tâche a déjà une demande de paiement',payment:existing.rows[0]});}
    const r=await c.query("INSERT INTO payments(task_id,payer_id,amount_gnf,provider,status,provider_reference,idempotency_key) VALUES($1,$2,$3,'manual','pending',$4,$5) RETURNING *",[task.id,req.user.sub,task.price_gnf,'MANUAL-'+Date.now(),idempotencyKey]);
    await c.query("UPDATE tasks SET payment_status='awaiting_admin' WHERE id=$1",[task.id]);
    await c.query('COMMIT');
    await audit(req.user.sub,'payment.submitted_manual','payment',r.rows[0].id,{task_id:task.id,amount_gnf:task.price_gnf});
    res.status(201).json({payment:r.rows[0],message:`Paiement par dépôt Orange Money / MTN / Wave au numéro : 613 34 06 90 (MSDMA). Montant exact : ${task.price_gnf} GNF. Après dépôt, clique sur « J’AI PAYÉ ».`});
  }catch(e){await c.query('ROLLBACK');next(e);}finally{c.release();}
});

app.post('/api/tasks/:id/paid',requireAuth,async(req,res,next)=>{try{const r=await pool.query("UPDATE tasks SET payment_status='awaiting_admin' WHERE id=$1 AND client_id=$2 RETURNING id,payment_status",[req.params.id,req.user.sub]);if(!r.rowCount)return res.status(404).json({error:'Tâche introuvable'});res.json({ok:true,status:r.rows[0].payment_status,message:'Paiement signalé. En attente de confirmation admin.'});}catch(e){next(e);}});

// Webhook skeleton for future licensed payment providers. Signature verification is required in production.
app.post('/api/payments/webhook/:provider',async(req,res,next)=>{
  const provider=String(req.params.provider||'').toLowerCase();
  try{
    const secret=process.env[`${provider.toUpperCase()}_WEBHOOK_SECRET`]||process.env.WEBHOOK_SECRET||'';
    if(secret){
      const signature=req.get('x-msdma-signature')||req.get('x-signature')||'';
      const expected=crypto.createHmac('sha256',secret).update(JSON.stringify(req.body)).digest('hex');
      if(!safeEqualHex(signature,expected)) return res.status(401).json({error:'Signature webhook invalide'});
    }
    const eventId=String(req.body?.event_id||req.body?.id||req.get('x-event-id')||'').trim();
    if(!eventId) return res.status(400).json({error:'event_id manquant'});
    const inserted=await pool.query('INSERT INTO webhook_events(provider,event_id,payload) VALUES($1,$2,$3) ON CONFLICT(provider,event_id) DO NOTHING RETURNING id',[provider,eventId,JSON.stringify(req.body)]);
    if(!inserted.rowCount) return res.json({ok:true,duplicate:true});
    const ref=String(req.body?.provider_reference||req.body?.transaction_id||req.body?.reference||'').trim();
    const status=String(req.body?.status||'').toLowerCase();
    if(ref){
      const mapped=status==='success'||status==='successful'||status==='completed'||status==='authorized'?'authorized':(status==='failed'||status==='cancelled'?'failed':null);
      if(mapped){
        const r=await pool.query("UPDATE payments SET status=$1,failure_reason=CASE WHEN $1='failed' THEN $2 ELSE NULL END,authorized_at=CASE WHEN $1='authorized' THEN COALESCE(authorized_at,now()) ELSE authorized_at END WHERE provider_reference=$3 RETURNING id,task_id,status",[mapped,String(req.body?.reason||'').slice(0,500),ref]);
        if(r.rowCount) await audit(null,'payment.webhook','payment',r.rows[0].id,{provider,event_id:eventId,status:mapped});
      }
    }
    res.json({ok:true,processed:true});
  }catch(e){next(e);}
});

app.get('/api/tasks/:id/payment',requireAuth,async(req,res,next)=>{try{const r=await pool.query('SELECT p.* FROM payments p JOIN tasks t ON t.id=p.task_id WHERE p.task_id=$1 AND (t.client_id=$2 OR t.provider_id=$2)',[req.params.id,req.user.sub]);if(!r.rowCount)return res.status(404).json({error:'Paiement introuvable'});res.json(r.rows[0]);}catch(e){next(e);}});

app.post('/api/tasks/:id/accept',requireAuth,async(req,res,next)=>{const c=await pool.connect();try{await c.query('BEGIN');const r=await c.query("UPDATE tasks SET status='accepted',provider_id=$1,accepted_at=now() WHERE id=$2 AND status='available' AND payment_status='paid' AND client_id<>$1 AND EXISTS (SELECT 1 FROM payments p WHERE p.task_id=tasks.id AND p.status='authorized') RETURNING *",[req.user.sub,req.params.id]);if(!r.rowCount){await c.query('ROLLBACK');return res.status(409).json({error:'Cette tâche n’est plus disponible ou vous en êtes le créateur'});}await c.query('COMMIT');res.json(r.rows[0]);}catch(e){await c.query('ROLLBACK');next(e);}finally{c.release();}});
app.post('/api/tasks/:id/complete',requireAuth,async(req,res,next)=>{const c=await pool.connect();try{await c.query('BEGIN');const r=await c.query("UPDATE tasks SET status='completed',completed_at=now() WHERE id=$1 AND provider_id=$2 AND status='accepted' RETURNING *",[req.params.id,req.user.sub]);if(!r.rowCount){await c.query('ROLLBACK');return res.status(409).json({error:'Mission introuvable ou non terminée'});}await c.query('COMMIT');await audit(req.user.sub,'task.completed','task',r.rows[0].id,{});res.json({task:r.rows[0],message:'Travail terminé. En attente du transfert par MSDMA.'});}catch(e){await c.query('ROLLBACK');next(e);}finally{c.release();}});

app.post('/api/messages',requireAuth,async(req,res,next)=>{const p=z.object({task_id:z.string().uuid(),receiver_id:z.string().uuid(),body:z.string().trim().min(1).max(2000)}).safeParse(req.body);if(!p.success)return res.status(400).json({error:'Message invalide'});try{const allowed=await pool.query('SELECT 1 FROM tasks WHERE id=$1 AND (client_id=$2 OR provider_id=$2)',[p.data.task_id,req.user.sub]);if(!allowed.rowCount)return res.status(403).json({error:'Accès refusé'});const r=await pool.query('INSERT INTO messages(task_id,sender_id,receiver_id,body) VALUES($1,$2,$3,$4) RETURNING *',[p.data.task_id,req.user.sub,p.data.receiver_id,p.data.body]);res.status(201).json(r.rows[0]);}catch(e){next(e);}});
app.get('/api/tasks/:id/messages',requireAuth,async(req,res,next)=>{try{const allowed=await pool.query('SELECT 1 FROM tasks WHERE id=$1 AND (client_id=$2 OR provider_id=$2)',[req.params.id,req.user.sub]);if(!allowed.rowCount)return res.status(403).json({error:'Accès refusé'});const r=await pool.query('SELECT * FROM messages WHERE task_id=$1 AND (sender_id=$2 OR receiver_id=$2) ORDER BY created_at ASC',[req.params.id,req.user.sub]);res.json(r.rows);}catch(e){next(e);}});

app.post('/api/admin/payments/:id/confirm',requireAuth,requireAdmin,async(req,res,next)=>{const c=await pool.connect();try{await c.query('BEGIN');const p=await c.query("UPDATE payments SET status='authorized',authorized_at=now() WHERE id=$1 AND status='pending' RETURNING *",[req.params.id]);if(!p.rowCount){await c.query('ROLLBACK');return res.status(409).json({error:'Paiement déjà traité ou introuvable'});}const payment=p.rows[0];const t=await c.query("UPDATE tasks SET payment_status='paid' WHERE id=$1 RETURNING id,provider_id,title",[payment.task_id]);if(t.rows[0]?.provider_id){await c.query("INSERT INTO notifications(user_id,title,body) VALUES($1,$2,$3)",[t.rows[0].provider_id,'Nouvelle mission payée','Nouvelle mission payée : '+t.rows[0].title]);}await c.query('COMMIT');await audit(req.user.sub,'payment.confirmed_manual','payment',payment.id,{task_id:payment.task_id});res.json({payment,message:'Paiement confirmé. Le prestataire est notifié.'});}catch(e){await c.query('ROLLBACK');next(e);}finally{c.release();}});

app.post('/api/admin/payments/:id/transfer',requireAuth,requireAdmin,async(req,res,next)=>{const c=await pool.connect();try{await c.query('BEGIN');const p=await c.query("SELECT * FROM payments WHERE id=$1 FOR UPDATE",[req.params.id]);if(!p.rowCount){await c.query('ROLLBACK');return res.status(404).json({error:'Paiement introuvable'});}const payment=p.rows[0];if(payment.status!=='authorized'){await c.query('ROLLBACK');return res.status(409).json({error:'Le paiement doit être confirmé avant le transfert'});}const payout=Math.floor(payment.amount_gnf*(1-COMMISSION_RATE));const commission=payment.amount_gnf-payout;const u=await c.query("SELECT provider_id FROM tasks WHERE id=$1",[payment.task_id]);const providerId=u.rows[0]?.provider_id;if(!providerId){await c.query('ROLLBACK');return res.status(409).json({error:'Aucun prestataire associé'});}const r=await c.query("UPDATE payments SET status='released',payee_id=$1,commission_gnf=$2,payout_gnf=$3,released_at=now() WHERE id=$4 RETURNING *",[providerId,commission,payout,payment.id]);await c.query("INSERT INTO notifications(user_id,title,body) VALUES($1,$2,$3)",[providerId,'Paiement à recevoir',`MSDMA : transfert manuel de ${payout} GNF (90%).`]);await c.query('COMMIT');await audit(req.user.sub,'payment.transfer_manual','payment',payment.id,{commission_gnf:commission,payout_gnf:payout});res.json({payment:r.rows[0],message:`À transférer au prestataire : ${payout} GNF. Commission MSDMA : ${commission} GNF.`});}catch(e){await c.query('ROLLBACK');next(e);}finally{c.release();}});

app.get('/api/notifications',requireAuth,async(req,res,next)=>{try{const r=await pool.query('SELECT * FROM notifications WHERE user_id=$1 ORDER BY created_at DESC LIMIT 100',[req.user.sub]);res.json(r.rows);}catch(e){next(e);}});

// Admin / moderation / platform economics
app.get('/api/admin/stats',requireAuth,requireAdmin,async(req,res,next)=>{try{const [u,t,p,c]=await Promise.all([pool.query("SELECT COUNT(*)::int AS total, COUNT(*) FILTER (WHERE account_status='active')::int AS active, COUNT(*) FILTER (WHERE verification_status='verified')::int AS verified FROM users"),pool.query("SELECT COUNT(*)::int AS total, COUNT(*) FILTER (WHERE status='available')::int AS available, COUNT(*) FILTER (WHERE status='accepted')::int AS accepted, COUNT(*) FILTER (WHERE status='completed')::int AS completed FROM tasks"),pool.query("SELECT COUNT(*)::int AS total, COALESCE(SUM(amount_gnf),0)::bigint AS gross, COALESCE(SUM(commission_gnf),0)::bigint AS commission, COALESCE(SUM(payout_gnf),0)::bigint AS payouts FROM payments WHERE status='released'"),pool.query("SELECT COUNT(*)::int AS pending FROM users WHERE verification_status='pending'")]);res.json({users:u.rows[0],tasks:t.rows[0],payments:p.rows[0],verification:c.rows[0],commission_rate:COMMISSION_RATE});}catch(e){next(e);}});
app.get('/api/admin/users',requireAuth,requireAdmin,async(req,res,next)=>{try{const r=await pool.query("SELECT id,name,email,phone,role,is_admin,account_status,verification_status,verified_at,created_at,vehicle_type,driver_status FROM users ORDER BY created_at DESC LIMIT 200");res.json(r.rows);}catch(e){next(e);}});
app.patch('/api/admin/users/:id/verify',requireAuth,requireAdmin,async(req,res,next)=>{const p=z.object({status:z.enum(['verified','rejected','pending','unverified']),note:z.string().trim().max(500).optional()}).safeParse(req.body);if(!p.success)return res.status(400).json({error:'Statut invalide'});try{const r=await pool.query("UPDATE users SET verification_status=$1,verified_at=CASE WHEN $1='verified' THEN now() ELSE NULL END WHERE id=$2 RETURNING id,name,phone,verification_status,verified_at,verification_note",[p.data.status,req.params.id]);if(!r.rowCount)return res.status(404).json({error:'Utilisateur introuvable'});await audit(req.user.sub,'user.verification.updated','user',req.params.id,{status:p.data.status,note:p.data.note||null}); res.json(r.rows[0]);}catch(e){next(e);}});
app.patch('/api/admin/users/:id/status',requireAuth,requireAdmin,async(req,res,next)=>{const p=z.object({status:z.enum(['active','suspended'])}).safeParse(req.body);if(!p.success)return res.status(400).json({error:'Statut invalide'});try{const r=await pool.query("UPDATE users SET account_status=$1 WHERE id=$2 AND is_admin=false RETURNING id,name,account_status",[p.data.status,req.params.id]);if(!r.rowCount)return res.status(404).json({error:'Utilisateur introuvable ou administrateur protégé'});res.json(r.rows[0]);}catch(e){next(e);}});
app.get('/api/admin/drivers',requireAuth,requireAdmin,async(req,res,next)=>{try{const r=await pool.query("SELECT id,name,phone,email,vehicle_type,driver_status,account_status,created_at FROM users WHERE role IN ('prestataire','both') ORDER BY created_at DESC LIMIT 200");res.json(r.rows);}catch(e){next(e);}});
app.patch('/api/admin/drivers/:id/status',requireAuth,requireAdmin,async(req,res,next)=>{const p=z.object({status:z.enum(['pending','accepted','refused'])}).safeParse(req.body);if(!p.success)return res.status(400).json({error:'Statut conducteur invalide'});try{const r=await pool.query("UPDATE users SET driver_status=$1 WHERE id=$2 AND role IN ('prestataire','both') RETURNING id,name,driver_status",[p.data.status,req.params.id]);if(!r.rowCount)return res.status(404).json({error:'Conducteur introuvable'});res.json(r.rows[0]);}catch(e){next(e);}});
app.get('/api/admin/tasks',requireAuth,requireAdmin,async(req,res,next)=>{try{const r=await pool.query("SELECT t.id,t.title,t.status,t.price_gnf,t.created_at,u.name AS client_name,p.name AS provider_name FROM tasks t JOIN users u ON u.id=t.client_id LEFT JOIN users p ON p.id=t.provider_id ORDER BY t.created_at DESC LIMIT 200");res.json(r.rows);}catch(e){next(e);}});
app.get('/api/admin/payments',requireAuth,requireAdmin,async(req,res,next)=>{try{const r=await pool.query("SELECT p.*,t.title,u.name AS payer_name,pp.name AS payee_name FROM payments p JOIN tasks t ON t.id=p.task_id JOIN users u ON u.id=p.payer_id LEFT JOIN users pp ON pp.id=p.payee_id ORDER BY p.created_at DESC LIMIT 200");res.json(r.rows);}catch(e){next(e);}});
app.get('/api/admin/export/summary',requireAuth,requireAdmin,async(req,res,next)=>{try{const r=await pool.query("SELECT date_trunc('day',released_at)::date AS day, COUNT(*)::int AS transactions, COALESCE(SUM(amount_gnf),0)::bigint AS gross, COALESCE(SUM(commission_gnf),0)::bigint AS commission, COALESCE(SUM(payout_gnf),0)::bigint AS payouts FROM payments WHERE status='released' GROUP BY 1 ORDER BY 1 DESC LIMIT 90");res.json(r.rows);}catch(e){next(e);}});

app.get('/api/admin/audit',requireAuth,requireAdmin,async(req,res,next)=>{try{const r=await pool.query(`SELECT a.*,u.name AS actor_name FROM audit_logs a LEFT JOIN users u ON u.id=a.actor_id ORDER BY a.created_at DESC LIMIT 300`);res.json(r.rows);}catch(e){next(e);}});

app.use(express.static(path.join(__dirname,'public')));
app.get('*',(req,res)=>{if(req.path.startsWith('/api/'))return res.status(404).json({error:'Route API introuvable'});res.sendFile(path.join(__dirname,'public','index.html'));});
app.use((err,_req,res,_next)=>{console.error(err);res.status(500).json({error:'Erreur serveur'});});

export { app };

if (process.env.NETLIFY !== 'true' && process.env.VERCEL !== '1') {
  const port=Number(process.env.PORT||4000);
  app.listen(port,()=>console.log(`MSDMA running on http://localhost:${port}`));
}


ALTER TABLE users ADD COLUMN IF NOT EXISTS email TEXT;
ALTER TABLE users ADD COLUMN IF NOT EXISTS vehicle_type TEXT;
ALTER TABLE users ADD COLUMN IF NOT EXISTS driver_status TEXT NOT NULL DEFAULT 'pending';
ALTER TABLE tasks ADD COLUMN IF NOT EXISTS payment_status TEXT NOT NULL DEFAULT 'unpaid';
CREATE TABLE IF NOT EXISTS notifications (id UUID PRIMARY KEY DEFAULT gen_random_uuid(), user_id UUID NOT NULL REFERENCES users(id) ON DELETE CASCADE, title TEXT NOT NULL, body TEXT NOT NULL, read_at TIMESTAMPTZ, created_at TIMESTAMPTZ NOT NULL DEFAULT now());
CREATE INDEX IF NOT EXISTS idx_notifications_user_created ON notifications(user_id, created_at DESC);
